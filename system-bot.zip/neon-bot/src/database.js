const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, 'neon.sqlite'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS config (
  guildId TEXT PRIMARY KEY,
  ticketCategoryId TEXT,
  ticketLogChannelId TEXT,
  applyChannelId TEXT,
  applyLogChannelId TEXT,
  applyActive INTEGER DEFAULT 0,
  staffRoleId TEXT,
  muteRoleId TEXT
);

CREATE TABLE IF NOT EXISTS ticket_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT,
  value TEXT,
  label TEXT,
  description TEXT,
  emoji TEXT
);

CREATE TABLE IF NOT EXISTS tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT,
  channelId TEXT,
  userId TEXT,
  typeValue TEXT,
  status TEXT DEFAULT 'open',
  claimedBy TEXT,
  createdAt INTEGER,
  closedAt INTEGER
);

CREATE TABLE IF NOT EXISTS warns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT,
  userId TEXT,
  moderatorId TEXT,
  reason TEXT,
  createdAt INTEGER
);

CREATE TABLE IF NOT EXISTS applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT,
  userId TEXT,
  answers TEXT,
  status TEXT DEFAULT 'pending',
  createdAt INTEGER
);

CREATE TABLE IF NOT EXISTS giveaways (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guildId TEXT,
  channelId TEXT,
  messageId TEXT,
  prize TEXT,
  winnerCount INTEGER,
  endsAt INTEGER,
  ended INTEGER DEFAULT 0,
  hostId TEXT,
  entrants TEXT DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS staff_stats (
  guildId TEXT,
  userId TEXT,
  ticketsClaimed INTEGER DEFAULT 0,
  PRIMARY KEY (guildId, userId)
);
`);

function getConfig(guildId) {
  let row = db.prepare('SELECT * FROM config WHERE guildId = ?').get(guildId);
  if (!row) {
    db.prepare('INSERT INTO config (guildId) VALUES (?)').run(guildId);
    row = db.prepare('SELECT * FROM config WHERE guildId = ?').get(guildId);
  }
  return row;
}

function updateConfig(guildId, fields) {
  getConfig(guildId); // تأكد من وجود صف
  const keys = Object.keys(fields);
  if (keys.length === 0) return;
  const setClause = keys.map((k) => `${k} = ?`).join(', ');
  const values = keys.map((k) => fields[k]);
  db.prepare(`UPDATE config SET ${setClause} WHERE guildId = ?`).run(...values, guildId);
}

module.exports = { db, getConfig, updateConfig };
