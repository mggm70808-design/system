const {
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require('discord.js');
const { db, getConfig } = require('./database');
const { THEME_COLOR } = require('./utils/helpers');

async function createTicket(interaction, typeValue) {
  const guild = interaction.guild;
  const config = getConfig(guild.id);

  if (!config.ticketCategoryId) {
    return interaction.reply({ content: '❌ لم يتم إعداد نظام التذاكر بعد.', ephemeral: true });
  }

  // امنع فتح أكثر من تذكرة مفتوحة لنفس العضو
  const existing = db
    .prepare("SELECT * FROM tickets WHERE guildId = ? AND userId = ? AND status = 'open'")
    .get(guild.id, interaction.user.id);
  if (existing) {
    return interaction.reply({ content: `❌ لديك تذكرة مفتوحة بالفعل: <#${existing.channelId}>`, ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });

  const overwrites = [
    { id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: interaction.user.id,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    },
    {
      id: guild.members.me.id,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels],
    },
  ];
  if (config.staffRoleId) {
    overwrites.push({
      id: config.staffRoleId,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
  }

  const channelName = `ticket-${interaction.user.username}`.slice(0, 90).toLowerCase().replace(/[^a-z0-9-]/g, '');

  const channel = await guild.channels.create({
    name: channelName || `ticket-${interaction.user.id}`,
    type: ChannelType.GuildText,
    parent: config.ticketCategoryId,
    permissionOverwrites: overwrites,
  });

  const info = db
    .prepare('INSERT INTO tickets (guildId, channelId, userId, typeValue, createdAt) VALUES (?, ?, ?, ?, ?)')
    .run(guild.id, channel.id, interaction.user.id, typeValue || 'general', Date.now());

  const embed = new EmbedBuilder()
    .setColor(THEME_COLOR)
    .setTitle('🎫 تذكرة جديدة')
    .setDescription(`مرحبًا ${interaction.user}! فريق الإدارة سيقوم بالرد عليك قريبًا.\n${typeValue ? `**نوع التذكرة:** ${typeValue}` : ''}`)
    .setTimestamp();

  const claimBtn = new ButtonBuilder().setCustomId(`ticket_claim_${info.lastInsertRowid}`).setLabel('📌 استلام').setStyle(ButtonStyle.Secondary);
  const closeBtn = new ButtonBuilder().setCustomId(`ticket_close_${info.lastInsertRowid}`).setLabel('🔒 إغلاق').setStyle(ButtonStyle.Danger);

  await channel.send({
    content: config.staffRoleId ? `<@&${config.staffRoleId}> ${interaction.user}` : `${interaction.user}`,
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(claimBtn, closeBtn)],
  });

  await interaction.editReply({ content: `✅ تم إنشاء تذكرتك: ${channel}` });
}

async function claimTicket(interaction, ticketId) {
  const ticket = db.prepare('SELECT * FROM tickets WHERE id = ?').get(ticketId);
  if (!ticket) return interaction.reply({ content: '❌ لم يتم العثور على هذه التذكرة.', ephemeral: true });
  if (ticket.claimedBy) {
    return interaction.reply({ content: `❌ هذه التذكرة تم استلامها بالفعل بواسطة <@${ticket.claimedBy}>.`, ephemeral: true });
  }

  db.prepare('UPDATE tickets SET claimedBy = ? WHERE id = ?').run(interaction.user.id, ticketId);

  const existingStat = db.prepare('SELECT * FROM staff_stats WHERE guildId = ? AND userId = ?').get(interaction.guild.id, interaction.user.id);
  if (existingStat) {
    db.prepare('UPDATE staff_stats SET ticketsClaimed = ticketsClaimed + 1 WHERE guildId = ? AND userId = ?').run(
      interaction.guild.id,
      interaction.user.id,
    );
  } else {
    db.prepare('INSERT INTO staff_stats (guildId, userId, ticketsClaimed) VALUES (?, ?, 1)').run(interaction.guild.id, interaction.user.id);
  }

  await interaction.reply({ content: `✅ تم استلام التذكرة بواسطة ${interaction.user}.` });
}

async function closeTicket(interaction, ticketId) {
  const ticket = db.prepare('SELECT * FROM tickets WHERE id = ?').get(ticketId);
  if (!ticket) return interaction.reply({ content: '❌ لم يتم العثور على هذه التذكرة.', ephemeral: true });

  db.prepare("UPDATE tickets SET status = 'closed', closedAt = ? WHERE id = ?").run(Date.now(), ticketId);

  const config = getConfig(interaction.guild.id);
  if (config.ticketLogChannelId) {
    const logChannel = await interaction.guild.channels.fetch(config.ticketLogChannelId).catch(() => null);
    if (logChannel) {
      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle('🔒 تم إغلاق تذكرة')
        .addFields(
          { name: 'صاحب التذكرة', value: `<@${ticket.userId}>`, inline: true },
          { name: 'أُغلقت بواسطة', value: `${interaction.user}`, inline: true },
          { name: 'النوع', value: `${ticket.typeValue}`, inline: true },
        )
        .setTimestamp();
      logChannel.send({ embeds: [embed] }).catch(() => {});
    }
  }

  await interaction.reply({ content: '🔒 سيتم إغلاق هذه التذكرة خلال 5 ثوانٍ...' });
  setTimeout(() => {
    interaction.channel.delete().catch(() => {});
  }, 5000);
}

module.exports = { createTicket, claimTicket, closeTicket };
