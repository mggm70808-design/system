const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { successEmbed } = require('../utils/helpers');
const { updateConfig } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-setup')
    .setDescription('Setup the ticket system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub
        .setName('channel')
        .setDescription('Setup the ticket system')
        .addChannelOption((opt) =>
          opt
            .setName('category')
            .setDescription('الكاتيجوري اللي تُنشأ فيه رومات التذاكر')
            .addChannelTypes(ChannelType.GuildCategory)
            .setRequired(true),
        ),
    ),
  async execute(interaction) {
    const category = interaction.options.getChannel('category');
    updateConfig(interaction.guild.id, { ticketCategoryId: category.id });
    await interaction.reply({
      embeds: [successEmbed(`تم تحديد **${category.name}** ككاتيجوري لإنشاء التذاكر.\nاستخدم \`/ticket\` لإرسال لوحة فتح التذاكر.`)],
    });
  },
};
