const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Bans a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو المراد حظره').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('سبب الحظر').setRequired(false))
    .addIntegerOption((opt) =>
      opt.setName('delete-messages').setDescription('حذف رسائل آخر كم يوم (0-7)').setRequired(false),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'لم يذكر سبب';
    const deleteDays = interaction.options.getInteger('delete-messages') || 0;

    const member = interaction.guild.members.cache.get(target.id);
    if (member && !member.bannable) {
      return interaction.reply({ embeds: [errorEmbed('لا أستطيع حظر هذا العضو (رتبته أعلى مني أو مالك السيرفر).')], ephemeral: true });
    }

    try {
      await interaction.guild.members.ban(target.id, {
        reason: `${reason} - بواسطة ${interaction.user.tag}`,
        deleteMessageSeconds: Math.min(Math.max(deleteDays, 0), 7) * 86400,
      });
      await interaction.reply({ embeds: [successEmbed(`تم حظر **${target.tag}** بنجاح.\n**السبب:** ${reason}`)] });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`فشل الحظر: ${err.message}`)], ephemeral: true });
    }
  },
};
