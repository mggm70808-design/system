const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Clears messages from the channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption((opt) =>
      opt.setName('amount').setDescription('عدد الرسائل (1-100)').setRequired(true).setMinValue(1).setMaxValue(100),
    )
    .addUserOption((opt) => opt.setName('user').setDescription('حذف رسائل عضو معين فقط').setRequired(false)),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const user = interaction.options.getUser('user');

    await interaction.deferReply({ ephemeral: true });
    try {
      const messages = await interaction.channel.messages.fetch({ limit: 100 });
      let toDelete = messages;
      if (user) toDelete = messages.filter((m) => m.author.id === user.id);
      toDelete = [...toDelete.values()].slice(0, amount);

      const deleted = await interaction.channel.bulkDelete(toDelete, true);
      await interaction.editReply({ embeds: [successEmbed(`تم حذف **${deleted.size}** رسالة.`)] });
    } catch (err) {
      await interaction.editReply({ embeds: [errorEmbed(`فشل الحذف (الرسائل الأقدم من 14 يوم لا يمكن حذفها): ${err.message}`)] });
    }
  },
};
