const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Shows bot latency information'),
  async execute(interaction) {
    const sent = await interaction.reply({ content: '🏓 جاري القياس...', fetchReply: true });
    const roundtrip = sent.createdTimestamp - interaction.createdTimestamp;
    const embed = baseEmbed()
      .setTitle('🏓 Pong!')
      .addFields(
        { name: 'زمن الاستجابة (Roundtrip)', value: `${roundtrip}ms`, inline: true },
        { name: 'زمن نبض الوايبسوكت (WS)', value: `${interaction.client.ws.ping}ms`, inline: true },
      );
    await interaction.editReply({ content: null, embeds: [embed] });
  },
};
