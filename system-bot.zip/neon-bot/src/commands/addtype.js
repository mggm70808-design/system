const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { baseEmbed, successEmbed, errorEmbed } = require('../utils/helpers');
const { db } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('add-type')
    .setDescription('Manage ticket types')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub
        .setName('add')
        .setDescription('إضافة نوع تذكرة جديد')
        .addStringOption((opt) => opt.setName('value').setDescription('المعرّف الفريد (بدون مسافات)').setRequired(true))
        .addStringOption((opt) => opt.setName('label').setDescription('الاسم الظاهر').setRequired(true))
        .addStringOption((opt) => opt.setName('description').setDescription('وصف قصير').setRequired(true))
        .addStringOption((opt) => opt.setName('emoji').setDescription('إيموجي (اختياري)').setRequired(false)),
    )
    .addSubcommand((sub) => sub.setName('list').setDescription('عرض جميع أنواع التذاكر الحالية'))
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription('حذف نوع تذكرة')
        .addStringOption((opt) => opt.setName('value').setDescription('المعرّف الفريد للنوع').setRequired(true)),
    ),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'add') {
      const value = interaction.options.getString('value').toLowerCase().replace(/\s+/g, '-');
      const label = interaction.options.getString('label');
      const description = interaction.options.getString('description');
      const emoji = interaction.options.getString('emoji') || null;

      const existing = db.prepare('SELECT * FROM ticket_types WHERE guildId = ? AND value = ?').get(guildId, value);
      if (existing) {
        return interaction.reply({ embeds: [errorEmbed('يوجد نوع تذكرة بنفس المعرّف بالفعل.')], ephemeral: true });
      }

      const count = db.prepare('SELECT COUNT(*) as c FROM ticket_types WHERE guildId = ?').get(guildId).c;
      if (count >= 25) {
        return interaction.reply({ embeds: [errorEmbed('لا يمكن إضافة أكثر من 25 نوع تذكرة (حد قوائم ديسكورد).')], ephemeral: true });
      }

      db.prepare('INSERT INTO ticket_types (guildId, value, label, description, emoji) VALUES (?, ?, ?, ?, ?)').run(
        guildId,
        value,
        label,
        description,
        emoji,
      );
      return interaction.reply({ embeds: [successEmbed(`تمت إضافة نوع التذكرة **${label}** (\`${value}\`).`)] });
    }

    if (sub === 'list') {
      const types = db.prepare('SELECT * FROM ticket_types WHERE guildId = ?').all(guildId);
      const embed = baseEmbed().setTitle('📋 أنواع التذاكر الحالية');
      if (!types.length) {
        embed.setDescription('لا توجد أنواع تذاكر مضافة بعد. استخدم `/add-type add` لإضافة نوع.');
      } else {
        embed.setDescription(
          types.map((t) => `${t.emoji || '🎫'} **${t.label}** (\`${t.value}\`)\n${t.description}`).join('\n\n'),
        );
      }
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'remove') {
      const value = interaction.options.getString('value').toLowerCase();
      const existing = db.prepare('SELECT * FROM ticket_types WHERE guildId = ? AND value = ?').get(guildId, value);
      if (!existing) {
        return interaction.reply({ embeds: [errorEmbed('لم يتم العثور على نوع تذكرة بهذا المعرّف.')], ephemeral: true });
      }
      db.prepare('DELETE FROM ticket_types WHERE guildId = ? AND value = ?').run(guildId, value);
      return interaction.reply({ embeds: [successEmbed(`تم حذف نوع التذكرة **${existing.label}**.`)] });
    }
  },
};
