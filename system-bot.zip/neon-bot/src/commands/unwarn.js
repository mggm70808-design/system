const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/helpers');
const { db } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unwarn')
    .setDescription('Removes a warning from a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(true))
    .addIntegerOption((opt) => opt.setName('warn-id').setDescription('رقم التحذير (# من أمر /warns)').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const warnId = interaction.options.getInteger('warn-id');

    const row = db
      .prepare('SELECT * FROM warns WHERE id = ? AND guildId = ? AND userId = ?')
      .get(warnId, interaction.guild.id, target.id);

    if (!row) {
      return interaction.reply({ embeds: [errorEmbed('لم يتم العثور على تحذير بهذا الرقم لهذا العضو.')], ephemeral: true });
    }

    db.prepare('DELETE FROM warns WHERE id = ?').run(warnId);
    await interaction.reply({ embeds: [successEmbed(`تم حذف التحذير **#${warnId}** من **${target.tag}**.`)] });
  },
};
