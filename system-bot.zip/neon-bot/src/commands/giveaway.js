const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { errorEmbed, parseDuration, formatMs, THEME_COLOR } = require('../utils/helpers');
const { db } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Create a new giveaway')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((opt) => opt.setName('prize').setDescription('الجائزة').setRequired(true))
    .addStringOption((opt) => opt.setName('duration').setDescription('المدة مثل: 10m, 2h, 1d').setRequired(true))
    .addIntegerOption((opt) => opt.setName('winners').setDescription('عدد الفائزين').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const prize = interaction.options.getString('prize');
    const durationStr = interaction.options.getString('duration');
    const winnerCount = interaction.options.getInteger('winners');

    const ms = parseDuration(durationStr);
    if (!ms) {
      return interaction.reply({ embeds: [errorEmbed('صيغة المدة غير صحيحة. مثال: 10m, 2h, 1d')], ephemeral: true });
    }

    const endsAt = Date.now() + ms;
    const embed = new EmbedBuilder()
      .setColor(THEME_COLOR)
      .setTitle('🎉 قيف اواي جديد!')
      .setDescription(`**الجائزة:** ${prize}\n**عدد الفائزين:** ${winnerCount}\n**ينتهي:** <t:${Math.floor(endsAt / 1000)}:R>\n**بواسطة:** ${interaction.user}`)
      .setFooter({ text: 'اضغط على الزر بالأسفل للمشاركة!' })
      .setTimestamp(endsAt);

    const button = new ButtonBuilder().setCustomId('giveaway_enter_placeholder').setLabel('🎉 دخول').setStyle(ButtonStyle.Primary);
    const row = new ActionRowBuilder().addComponents(button);

    await interaction.reply({ content: '✅ تم إنشاء القيف اواي.', ephemeral: true });
    const message = await interaction.channel.send({ embeds: [embed], components: [row] });

    const info = db
      .prepare('INSERT INTO giveaways (guildId, channelId, messageId, prize, winnerCount, endsAt, hostId) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(interaction.guild.id, interaction.channel.id, message.id, prize, winnerCount, endsAt, interaction.user.id);

    const realButton = new ButtonBuilder().setCustomId(`giveaway_enter_${info.lastInsertRowid}`).setLabel('🎉 دخول').setStyle(ButtonStyle.Primary);
    await message.edit({ components: [new ActionRowBuilder().addComponents(realButton)] });

    require('../giveawayManager').scheduleGiveawayCheck(interaction.client, ms + 500);
  },
};
