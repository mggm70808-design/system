const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { baseEmbed } = require('../utils/helpers');
const { db } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warns')
    .setDescription('Shows warnings for a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const rows = db
      .prepare('SELECT * FROM warns WHERE guildId = ? AND userId = ? ORDER BY id DESC')
      .all(interaction.guild.id, target.id);

    const embed = baseEmbed().setTitle(`تحذيرات ${target.tag} (${rows.length})`);
    if (!rows.length) {
      embed.setDescription('لا يوجد أي تحذيرات لهذا العضو. ✅');
    } else {
      embed.setDescription(
        rows
          .slice(0, 15)
          .map(
            (w) =>
              `**#${w.id}** — ${w.reason}\nبواسطة <@${w.moderatorId}> • <t:${Math.floor(w.createdAt / 1000)}:R>`,
          )
          .join('\n\n'),
      );
    }
    await interaction.reply({ embeds: [embed] });
  },
};
