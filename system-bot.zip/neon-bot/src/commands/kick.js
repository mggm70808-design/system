const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kicks a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو المراد طرده').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('سبب الطرد').setRequired(false)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'لم يذكر سبب';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) return interaction.reply({ embeds: [errorEmbed('هذا العضو غير موجود في السيرفر.')], ephemeral: true });
    if (!member.kickable) {
      return interaction.reply({ embeds: [errorEmbed('لا أستطيع طرد هذا العضو (رتبته أعلى مني أو مالك السيرفر).')], ephemeral: true });
    }

    try {
      await member.kick(`${reason} - بواسطة ${interaction.user.tag}`);
      await interaction.reply({ embeds: [successEmbed(`تم طرد **${target.tag}** بنجاح.\n**السبب:** ${reason}`)] });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`فشل الطرد: ${err.message}`)], ephemeral: true });
    }
  },
};
