const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { baseEmbed, successEmbed, errorEmbed } = require('../utils/helpers');
const { db, getConfig, updateConfig } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('apply')
    .setDescription('Application system')
    .addSubcommand((sub) =>
      sub
        .setName('setup')
        .setDescription('Set up the application system in a channel')
        .addChannelOption((opt) =>
          opt.setName('channel').setDescription('الروم اللي بينزل فيها زر التقديم').addChannelTypes(ChannelType.GuildText).setRequired(true),
        )
        .addChannelOption((opt) =>
          opt
            .setName('log-channel')
            .setDescription('روم استقبال التقديمات (اختياري = نفس روم التقديم)')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(false),
        ),
    )
    .addSubcommand((sub) => sub.setName('status').setDescription('Check the status of your application'))
    .addSubcommand((sub) =>
      sub.setName('clear').setDescription('Clear all applications from the database (Admin only)'),
    ),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'setup') {
      if (!interaction.memberPermissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [errorEmbed('تحتاج صلاحية "إدارة السيرفر" لاستخدام هذا الأمر.')], ephemeral: true });
      }
      const channel = interaction.options.getChannel('channel');
      const logChannel = interaction.options.getChannel('log-channel') || channel;

      updateConfig(guildId, { applyChannelId: channel.id, applyLogChannelId: logChannel.id, applyActive: 1 });

      const embed = baseEmbed()
        .setTitle('📝 التقديم على وظيفة الإدارة')
        .setDescription('اضغط على الزر بالأسفل لتقديم طلبك للانضمام لفريق الإدارة.');
      const button = new ButtonBuilder().setCustomId('apply_start').setLabel('📝 قدم الآن').setStyle(ButtonStyle.Success);

      await channel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(button)] });
      return interaction.reply({ embeds: [successEmbed(`تم إعداد نظام التقديم في ${channel}.`)], ephemeral: true });
    }

    if (sub === 'status') {
      const application = db
        .prepare('SELECT * FROM applications WHERE guildId = ? AND userId = ? ORDER BY id DESC LIMIT 1')
        .get(guildId, interaction.user.id);

      if (!application) {
        return interaction.reply({ embeds: [errorEmbed('لم تقدم أي طلب في هذا السيرفر بعد.')], ephemeral: true });
      }

      const statusText = { pending: '🕐 قيد المراجعة', accepted: '✅ مقبول', rejected: '❌ مرفوض' }[application.status];
      const embed = baseEmbed()
        .setTitle('📝 حالة تقديمك')
        .addFields(
          { name: 'الحالة', value: statusText, inline: true },
          { name: 'تاريخ التقديم', value: `<t:${Math.floor(application.createdAt / 1000)}:R>`, inline: true },
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'clear') {
      if (!interaction.memberPermissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ embeds: [errorEmbed('تحتاج صلاحية "المسؤول" (Administrator) لاستخدام هذا الأمر.')], ephemeral: true });
      }
      db.prepare('DELETE FROM applications WHERE guildId = ?').run(guildId);
      return interaction.reply({ embeds: [successEmbed('تم حذف جميع التقديمات من قاعدة البيانات.')], ephemeral: true });
    }
  },
};
