const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed, parseDuration, formatMs } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeouts a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(true))
    .addStringOption((opt) =>
      opt.setName('duration').setDescription('المدة مثل: 10m, 2h, 1d').setRequired(true),
    )
    .addStringOption((opt) => opt.setName('reason').setDescription('السبب').setRequired(false)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const durationStr = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'لم يذكر سبب';
    const member = interaction.guild.members.cache.get(target.id);

    const ms = parseDuration(durationStr);
    if (!ms || ms > 28 * 86400000) {
      return interaction.reply({ embeds: [errorEmbed('صيغة المدة غير صحيحة أو أكبر من 28 يوم. مثال: 10m, 2h, 1d')], ephemeral: true });
    }
    if (!member) return interaction.reply({ embeds: [errorEmbed('العضو غير موجود.')], ephemeral: true });
    if (!member.moderatable) {
      return interaction.reply({ embeds: [errorEmbed('لا أستطيع إعطاء تايم آوت لهذا العضو.')], ephemeral: true });
    }

    try {
      await member.timeout(ms, `${reason} - بواسطة ${interaction.user.tag}`);
      await interaction.reply({
        embeds: [successEmbed(`تم إعطاء **${target.tag}** تايم آوت لمدة **${formatMs(ms)}**.\n**السبب:** ${reason}`)],
      });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`فشل: ${err.message}`)], ephemeral: true });
    }
  },
};
