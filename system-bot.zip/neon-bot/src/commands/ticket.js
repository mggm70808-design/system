const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { baseEmbed, errorEmbed } = require('../utils/helpers');
const { db, getConfig } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('إرسال نظام التذاكر')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction) {
    const config = getConfig(interaction.guild.id);
    if (!config.ticketCategoryId) {
      return interaction.reply({
        embeds: [errorEmbed('لم يتم إعداد نظام التذاكر بعد. استخدم `/ticket-setup channel` أولاً.')],
        ephemeral: true,
      });
    }

    const types = db.prepare('SELECT * FROM ticket_types WHERE guildId = ?').all(interaction.guild.id);

    const embed = baseEmbed()
      .setTitle('🎫 نظام التذاكر')
      .setDescription('لفتح تذكرة جديدة والتواصل مع فريق الإدارة، اضغط على الزر/القائمة بالأسفل.');

    const components = [];

    if (types.length) {
      const menu = new StringSelectMenuBuilder()
        .setCustomId('ticket_select')
        .setPlaceholder('اختر نوع التذكرة...')
        .addOptions(
          types.map((t) => ({
            label: t.label,
            value: t.value,
            description: t.description?.slice(0, 100),
            emoji: t.emoji || undefined,
          })),
        );
      components.push(new ActionRowBuilder().addComponents(menu));
    } else {
      const button = new ButtonBuilder().setCustomId('ticket_open_default').setLabel('📩 فتح تذكرة').setStyle(ButtonStyle.Primary);
      components.push(new ActionRowBuilder().addComponents(button));
    }

    await interaction.channel.send({ embeds: [embed], components });
    await interaction.reply({ content: '✅ تم إرسال لوحة التذاكر.', ephemeral: true });
  },
};
