const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { baseEmbed } = require('../utils/helpers');
const { db } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('Statistics')
    .addSubcommand((sub) =>
      sub
        .setName('admin')
        .setDescription('عرض إحصايات مشرف معين')
        .addUserOption((opt) => opt.setName('user').setDescription('المشرف (اتركه فاضي لعرض إحصايات عامة)').setRequired(false)),
    )
    .addSubcommand((sub) => sub.setName('leaderboard').setDescription('عرض لوحة المتصدرين للمشرفين')),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'admin') {
      const targetUser = interaction.options.getUser('user');

      if (targetUser) {
        const row = db.prepare('SELECT * FROM staff_stats WHERE guildId = ? AND userId = ?').get(guildId, targetUser.id);
        const embed = baseEmbed()
          .setTitle(`📊 إحصائيات ${targetUser.tag}`)
          .addFields({ name: 'تذاكر تم استلامها', value: `${row?.ticketsClaimed || 0}`, inline: true });
        return interaction.reply({ embeds: [embed] });
      }

      const totalTickets = db.prepare('SELECT COUNT(*) as c FROM tickets WHERE guildId = ?').get(guildId).c;
      const openTickets = db.prepare("SELECT COUNT(*) as c FROM tickets WHERE guildId = ? AND status = 'open'").get(guildId).c;
      const totalWarns = db.prepare('SELECT COUNT(*) as c FROM warns WHERE guildId = ?').get(guildId).c;
      const totalApplications = db.prepare('SELECT COUNT(*) as c FROM applications WHERE guildId = ?').get(guildId).c;

      const embed = baseEmbed()
        .setTitle('📊 إحصائيات السيرفر العامة')
        .addFields(
          { name: '🎫 إجمالي التذاكر', value: `${totalTickets}`, inline: true },
          { name: '📬 تذاكر مفتوحة حاليًا', value: `${openTickets}`, inline: true },
          { name: '⚠️ إجمالي التحذيرات', value: `${totalWarns}`, inline: true },
          { name: '📝 إجمالي التقديمات', value: `${totalApplications}`, inline: true },
        );
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'leaderboard') {
      const rows = db
        .prepare('SELECT * FROM staff_stats WHERE guildId = ? ORDER BY ticketsClaimed DESC LIMIT 10')
        .all(guildId);

      const embed = baseEmbed().setTitle('🏆 لوحة المتصدرين - استلام التذاكر');
      if (!rows.length) {
        embed.setDescription('لا توجد بيانات حتى الآن.');
      } else {
        const medals = ['🥇', '🥈', '🥉'];
        embed.setDescription(
          rows.map((r, i) => `${medals[i] || `**${i + 1}.**`} <@${r.userId}> — **${r.ticketsClaimed}** تذكرة`).join('\n'),
        );
      }
      return interaction.reply({ embeds: [embed] });
    }
  },
};
