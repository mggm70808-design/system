const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unbans a user by ID')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption((opt) => opt.setName('user-id').setDescription('آيدي المستخدم').setRequired(true)),
  async execute(interaction) {
    const userId = interaction.options.getString('user-id');
    try {
      await interaction.guild.members.unban(userId);
      await interaction.reply({ embeds: [successEmbed(`تم فك الحظر عن المستخدم صاحب الآيدي \`${userId}\`.`)] });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed('هذا المستخدم غير محظور أو الآيدي غير صحيح.')], ephemeral: true });
    }
  },
};
