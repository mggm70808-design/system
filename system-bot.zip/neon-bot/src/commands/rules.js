const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { baseEmbed, successEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rules')
    .setDescription('Rules system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub
        .setName('setup')
        .setDescription('Setup the rules system')
        .addChannelOption((opt) =>
          opt.setName('channel').setDescription('روم القوانين').addChannelTypes(ChannelType.GuildText).setRequired(true),
        )
        .addStringOption((opt) => opt.setName('rules').setDescription('نص القوانين').setRequired(true))
        .addRoleOption((opt) =>
          opt.setName('verified-role').setDescription('الرتبة اللي تُعطى عند الموافقة (اختياري)').setRequired(false),
        ),
    ),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const rulesText = interaction.options.getString('rules');
    const role = interaction.options.getRole('verified-role');

    const embed = baseEmbed().setTitle('📜 قوانين السيرفر').setDescription(rulesText);

    const components = [];
    if (role) {
      const button = new ButtonBuilder()
        .setCustomId(`rules_accept_${role.id}`)
        .setLabel('✅ أوافق على القوانين')
        .setStyle(ButtonStyle.Success);
      components.push(new ActionRowBuilder().addComponents(button));
    }

    await channel.send({ embeds: [embed], components });
    await interaction.reply({ embeds: [successEmbed(`تم إرسال القوانين في ${channel}.`)], ephemeral: true });
  },
};
