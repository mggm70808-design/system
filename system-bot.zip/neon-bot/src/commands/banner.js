const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('banner')
    .setDescription('Shows user or server banner')
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(false))
    .addBooleanOption((opt) => opt.setName('server').setDescription('عرض بانر السيرفر بدلاً من المستخدم').setRequired(false)),
  async execute(interaction) {
    const wantsServer = interaction.options.getBoolean('server');

    if (wantsServer) {
      const guild = interaction.guild;
      const bannerURL = guild.bannerURL({ size: 1024 });
      if (!bannerURL) {
        return interaction.reply({ embeds: [errorEmbed('السيرفر ما عنده بانر حاليًا.')], ephemeral: true });
      }
      const embed = baseEmbed().setTitle(`بانر سيرفر ${guild.name}`).setImage(bannerURL);
      return interaction.reply({ embeds: [embed] });
    }

    const targetUser = interaction.options.getUser('user') || interaction.user;
    const fetched = await interaction.client.users.fetch(targetUser.id, { force: true });
    const bannerURL = fetched.bannerURL({ size: 1024 });
    if (!bannerURL) {
      return interaction.reply({ embeds: [errorEmbed('هذا العضو ما عنده بانر.')], ephemeral: true });
    }
    const embed = baseEmbed().setTitle(`بانر ${fetched.username}`).setImage(bannerURL);
    await interaction.reply({ embeds: [embed] });
  },
};
