const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setnick')
    .setDescription("Changes a member's nickname")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(true))
    .addStringOption((opt) =>
      opt.setName('nickname').setDescription('الاسم الجديد (اتركه فاضي لإزالته)').setRequired(false),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const nickname = interaction.options.getString('nickname');
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) return interaction.reply({ embeds: [errorEmbed('العضو غير موجود.')], ephemeral: true });
    if (!member.manageable) {
      return interaction.reply({ embeds: [errorEmbed('لا أستطيع تعديل اسم هذا العضو.')], ephemeral: true });
    }

    try {
      await member.setNickname(nickname || null, `بواسطة ${interaction.user.tag}`);
      await interaction.reply({
        embeds: [successEmbed(nickname ? `تم تغيير اسم **${target.tag}** إلى **${nickname}**.` : `تم إزالة اللقب عن **${target.tag}**.`)],
      });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`فشل: ${err.message}`)], ephemeral: true });
    }
  },
};
