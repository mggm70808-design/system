const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rrole')
    .setDescription('Removes a role from a user')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(true))
    .addRoleOption((opt) => opt.setName('role').setDescription('الرتبة').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) return interaction.reply({ embeds: [errorEmbed('العضو غير موجود.')], ephemeral: true });
    if (!member.roles.cache.has(role.id)) {
      return interaction.reply({ embeds: [errorEmbed('هذا العضو لا يملك هذه الرتبة أصلاً.')], ephemeral: true });
    }

    try {
      await member.roles.remove(role, `بواسطة ${interaction.user.tag}`);
      await interaction.reply({ embeds: [successEmbed(`تم إزالة رتبة ${role} من **${target.tag}**.`)] });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`فشل: ${err.message}`)], ephemeral: true });
    }
  },
};
