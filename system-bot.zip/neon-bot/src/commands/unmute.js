const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/helpers');
const { getConfig } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Unmutes a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const member = interaction.guild.members.cache.get(target.id);
    const config = getConfig(interaction.guild.id);

    if (!member) return interaction.reply({ embeds: [errorEmbed('العضو غير موجود.')], ephemeral: true });
    if (!config.muteRoleId || !member.roles.cache.has(config.muteRoleId)) {
      return interaction.reply({ embeds: [errorEmbed('هذا العضو غير مكتوم.')], ephemeral: true });
    }

    try {
      await member.roles.remove(config.muteRoleId, `أزيل بواسطة ${interaction.user.tag}`);
      await interaction.reply({ embeds: [successEmbed(`تم فك الكتم عن **${target.tag}**.`)] });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`فشل: ${err.message}`)], ephemeral: true });
    }
  },
};
