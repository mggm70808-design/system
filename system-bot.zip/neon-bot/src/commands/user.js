const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('user')
    .setDescription('Shows user information')
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(false)),
  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const member = interaction.guild.members.cache.get(user.id);
    const embed = baseEmbed()
      .setTitle(`معلومات ${user.username}`)
      .setThumbnail(user.displayAvatarURL({ size: 512 }))
      .addFields(
        { name: '🏷️ اليوزر', value: `${user.tag}`, inline: true },
        { name: '🆔 الآيدي', value: `${user.id}`, inline: true },
        { name: '🤖 بوت؟', value: user.bot ? 'نعم' : 'لا', inline: true },
        { name: '📅 تاريخ إنشاء الحساب', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true },
      );
    if (member) {
      embed.addFields(
        { name: '📥 تاريخ الانضمام', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`, inline: true },
        {
          name: '🎭 الرتب',
          value: member.roles.cache.filter((r) => r.id !== interaction.guild.id).map((r) => `${r}`).join(', ') || 'لا يوجد',
        },
      );
    }
    await interaction.reply({ embeds: [embed] });
  },
};
