const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/helpers');
const { db } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warns a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('سبب التحذير').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    db.prepare(
      'INSERT INTO warns (guildId, userId, moderatorId, reason, createdAt) VALUES (?, ?, ?, ?, ?)',
    ).run(interaction.guild.id, target.id, interaction.user.id, reason, Date.now());

    const count = db
      .prepare('SELECT COUNT(*) as c FROM warns WHERE guildId = ? AND userId = ?')
      .get(interaction.guild.id, target.id).c;

    await interaction.reply({
      embeds: [successEmbed(`تم تحذير **${target.tag}**.\n**السبب:** ${reason}\n**إجمالي التحذيرات:** ${count}`)],
    });

    target
      .send(`⚠️ تم تحذيرك في سيرفر **${interaction.guild.name}**.\n**السبب:** ${reason}`)
      .catch(() => {});
  },
};
