const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Shows user avatar')
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(false)),
  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const embed = baseEmbed()
      .setTitle(`صورة ${user.username}`)
      .setImage(user.displayAvatarURL({ size: 1024, extension: 'png' }));
    await interaction.reply({ embeds: [embed] });
  },
};
