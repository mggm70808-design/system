const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder().setName('server').setDescription('Shows server information'),
  async execute(interaction) {
    const guild = interaction.guild;
    const owner = await guild.fetchOwner();
    const embed = baseEmbed()
      .setTitle(guild.name)
      .setThumbnail(guild.iconURL({ size: 512 }))
      .addFields(
        { name: '👑 المالك', value: `${owner.user.tag}`, inline: true },
        { name: '👥 الأعضاء', value: `${guild.memberCount}`, inline: true },
        { name: '📅 تاريخ الإنشاء', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '💬 عدد الرومات', value: `${guild.channels.cache.size}`, inline: true },
        { name: '🎭 عدد الرتب', value: `${guild.roles.cache.size}`, inline: true },
        { name: '😀 عدد الإيموجيات', value: `${guild.emojis.cache.size}`, inline: true },
        { name: '🔒 مستوى التحقق', value: `${guild.verificationLevel}`, inline: true },
        { name: '🆔 آيدي السيرفر', value: `${guild.id}`, inline: true },
      );
    if (guild.bannerURL()) embed.setImage(guild.bannerURL({ size: 1024 }));
    await interaction.reply({ embeds: [embed] });
  },
};
