const { SlashCommandBuilder } = require('discord.js');
const { baseEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder().setName('roles').setDescription('Shows server roles information'),
  async execute(interaction) {
    const roles = interaction.guild.roles.cache
      .filter((r) => r.id !== interaction.guild.id)
      .sort((a, b) => b.position - a.position);
    const chunks = [];
    let current = '';
    roles.forEach((r) => {
      const line = `${r} — \`${r.members.size}\` عضو\n`;
      if ((current + line).length > 1000) {
        chunks.push(current);
        current = '';
      }
      current += line;
    });
    if (current) chunks.push(current);

    const embed = baseEmbed()
      .setTitle(`رتب سيرفر ${interaction.guild.name} (${roles.size})`)
      .setDescription(chunks[0] || 'لا توجد رتب.');
    for (let i = 1; i < chunks.length; i++) {
      embed.addFields({ name: '\u200b', value: chunks[i] });
    }
    await interaction.reply({ embeds: [embed] });
  },
};
