const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { successEmbed, errorEmbed, parseDuration, formatMs } = require('../utils/helpers');
const { getConfig, updateConfig } = require('../database');

async function getOrCreateMuteRole(guild) {
  const config = getConfig(guild.id);
  let role = config.muteRoleId ? guild.roles.cache.get(config.muteRoleId) : null;
  if (!role) {
    role = await guild.roles.create({
      name: 'Muted',
      color: 'Grey',
      permissions: [],
      reason: 'إنشاء رتبة الكتم تلقائيًا',
    });
    updateConfig(guild.id, { muteRoleId: role.id });
    // إعداد الصلاحيات في كل القنوات
    for (const channel of guild.channels.cache.values()) {
      if (channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildVoice) {
        try {
          await channel.permissionOverwrites.edit(role, { SendMessages: false, Speak: false, AddReactions: false });
        } catch (_) {}
      }
    }
  }
  return role;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mutes a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(true))
    .addStringOption((opt) => opt.setName('duration').setDescription('المدة مثل: 10m, 2h, 1d (اتركه فاضي = دائم)').setRequired(false))
    .addStringOption((opt) => opt.setName('reason').setDescription('السبب').setRequired(false)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const durationStr = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'لم يذكر سبب';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) return interaction.reply({ embeds: [errorEmbed('العضو غير موجود.')], ephemeral: true });

    let ms = null;
    if (durationStr) {
      ms = parseDuration(durationStr);
      if (!ms) return interaction.reply({ embeds: [errorEmbed('صيغة المدة غير صحيحة. مثال: 10m, 2h, 1d')], ephemeral: true });
    }

    try {
      const role = await getOrCreateMuteRole(interaction.guild);
      await member.roles.add(role, `${reason} - بواسطة ${interaction.user.tag}`);

      if (ms) {
        setTimeout(async () => {
          try {
            const freshMember = await interaction.guild.members.fetch(target.id).catch(() => null);
            if (freshMember && freshMember.roles.cache.has(role.id)) {
              await freshMember.roles.remove(role, 'انتهاء مدة الكتم');
            }
          } catch (_) {}
        }, ms);
      }

      await interaction.reply({
        embeds: [successEmbed(`تم كتم **${target.tag}**${ms ? ` لمدة **${formatMs(ms)}**` : ' بشكل دائم'}.\n**السبب:** ${reason}`)],
      });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`فشل: ${err.message}`)], ephemeral: true });
    }
  },
};
