const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('move')
    .setDescription('Moves a member to your voice channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.MoveMembers)
    .addUserOption((opt) => opt.setName('user').setDescription('العضو').setRequired(true))
    .addChannelOption((opt) =>
      opt
        .setName('channel')
        .setDescription('روم صوتي محدد (اتركه فاضي = رومك الحالي)')
        .addChannelTypes(ChannelType.GuildVoice)
        .setRequired(false),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const member = interaction.guild.members.cache.get(target.id);
    const destChannel = interaction.options.getChannel('channel') || interaction.member.voice.channel;

    if (!member || !member.voice.channel) {
      return interaction.reply({ embeds: [errorEmbed('هذا العضو ليس في روم صوتي حاليًا.')], ephemeral: true });
    }
    if (!destChannel) {
      return interaction.reply({ embeds: [errorEmbed('حدد روم صوتي أو ادخل روم صوتي أولاً.')], ephemeral: true });
    }

    try {
      await member.voice.setChannel(destChannel);
      await interaction.reply({ embeds: [successEmbed(`تم نقل **${target.tag}** إلى ${destChannel}.`)] });
    } catch (err) {
      await interaction.reply({ embeds: [errorEmbed(`فشل: ${err.message}`)], ephemeral: true });
    }
  },
};
