const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { errorEmbed } = require('../utils/helpers');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('Send a message as the bot')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addSubcommand((sub) =>
      sub
        .setName('with-embed')
        .setDescription('Say with an embed')
        .addStringOption((opt) => opt.setName('description').setDescription('نص الرسالة').setRequired(true))
        .addStringOption((opt) => opt.setName('image').setDescription('رابط صورة (اختياري)').setRequired(false))
        .addStringOption((opt) =>
          opt.setName('color').setDescription('لون الإيمبيد بصيغة hex مثل #9b59ff (اختياري)').setRequired(false),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('without-embed')
        .setDescription('Say without an embed')
        .addStringOption((opt) => opt.setName('message').setDescription('نص الرسالة').setRequired(true)),
    ),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'without-embed') {
      const message = interaction.options.getString('message');
      await interaction.channel.send({ content: message });
      return interaction.reply({ content: '✅ تم إرسال الرسالة.', ephemeral: true });
    }

    // with-embed
    const description = interaction.options.getString('description');
    const image = interaction.options.getString('image');
    const colorInput = interaction.options.getString('color');

    const embed = new EmbedBuilder().setDescription(description);

    if (colorInput) {
      const hex = /^#?[0-9A-Fa-f]{6}$/.test(colorInput) ? colorInput.replace('#', '') : null;
      if (!hex) {
        return interaction.reply({ embeds: [errorEmbed('صيغة اللون غير صحيحة. مثال: #9b59ff')], ephemeral: true });
      }
      embed.setColor(parseInt(hex, 16));
    } else {
      embed.setColor(0x9b59ff);
    }

    if (image) {
      try {
        embed.setImage(image);
      } catch (_) {
        return interaction.reply({ embeds: [errorEmbed('رابط الصورة غير صالح.')], ephemeral: true });
      }
    }

    await interaction.channel.send({ embeds: [embed] });
    await interaction.reply({ content: '✅ تم إرسال الرسالة.', ephemeral: true });
  },
};
