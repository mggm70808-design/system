const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { baseEmbed, successEmbed, errorEmbed } = require('../utils/helpers');
const { getConfig, updateConfig, db } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Bot setup')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) =>
      sub
        .setName('channels')
        .setDescription('إعداد القنوات المطلوبة للبوت')
        .addChannelOption((opt) =>
          opt
            .setName('ticket-category')
            .setDescription('الكاتيجوري اللي تنشأ فيه التذاكر')
            .addChannelTypes(ChannelType.GuildCategory)
            .setRequired(false),
        )
        .addChannelOption((opt) =>
          opt
            .setName('ticket-log-channel')
            .setDescription('روم سجل التذاكر')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(false),
        )
        .addRoleOption((opt) => opt.setName('staff-role').setDescription('رتبة الإدارة/الدعم').setRequired(false)),
    )
    .addSubcommand((sub) => sub.setName('config').setDescription('عرض التكوين الحالي للبوت'))
    .addSubcommand((sub) => sub.setName('test').setDescription('اختبار اتصال البوت وقاعدة البيانات')),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (sub === 'channels') {
      const ticketCategory = interaction.options.getChannel('ticket-category');
      const ticketLog = interaction.options.getChannel('ticket-log-channel');
      const staffRole = interaction.options.getRole('staff-role');

      const fields = {};
      if (ticketCategory) fields.ticketCategoryId = ticketCategory.id;
      if (ticketLog) fields.ticketLogChannelId = ticketLog.id;
      if (staffRole) fields.staffRoleId = staffRole.id;

      if (!Object.keys(fields).length) {
        return interaction.reply({ embeds: [errorEmbed('حدد خيار واحد على الأقل لتعديله.')], ephemeral: true });
      }

      updateConfig(guildId, fields);
      return interaction.reply({ embeds: [successEmbed('تم تحديث إعدادات القنوات بنجاح.')] });
    }

    if (sub === 'config') {
      const config = getConfig(guildId);
      const embed = baseEmbed()
        .setTitle('⚙️ التكوين الحالي للبوت')
        .addFields(
          { name: 'كاتيجوري التذاكر', value: config.ticketCategoryId ? `<#${config.ticketCategoryId}>` : 'غير محدد', inline: true },
          { name: 'روم سجل التذاكر', value: config.ticketLogChannelId ? `<#${config.ticketLogChannelId}>` : 'غير محدد', inline: true },
          { name: 'رتبة الإدارة', value: config.staffRoleId ? `<@&${config.staffRoleId}>` : 'غير محدد', inline: true },
          { name: 'روم التقديمات', value: config.applyChannelId ? `<#${config.applyChannelId}>` : 'غير محدد', inline: true },
          { name: 'روم سجل التقديمات', value: config.applyLogChannelId ? `<#${config.applyLogChannelId}>` : 'غير محدد', inline: true },
          { name: 'نظام التقديم مفعّل؟', value: config.applyActive ? 'نعم ✅' : 'لا ❌', inline: true },
          { name: 'رتبة الكتم', value: config.muteRoleId ? `<@&${config.muteRoleId}>` : 'لم تُنشأ بعد', inline: true },
        );
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'test') {
      const results = [];

      // اختبار قاعدة البيانات
      try {
        db.prepare('SELECT 1').get();
        results.push('✅ قاعدة البيانات تعمل بشكل صحيح.');
      } catch (err) {
        results.push(`❌ خطأ في قاعدة البيانات: ${err.message}`);
      }

      // اختبار صلاحيات البوت
      const me = interaction.guild.members.me;
      const perms = [
        ['ManageChannels', 'إدارة القنوات'],
        ['ManageRoles', 'إدارة الرتب'],
        ['KickMembers', 'طرد الأعضاء'],
        ['BanMembers', 'حظر الأعضاء'],
        ['ModerateMembers', 'تايم آوت'],
        ['ManageMessages', 'إدارة الرسائل'],
      ];
      const missing = perms.filter(([flag]) => !me.permissions.has(PermissionFlagsBits[flag]));
      if (missing.length) {
        results.push(`⚠️ صلاحيات ناقصة: ${missing.map((m) => m[1]).join(', ')}`);
      } else {
        results.push('✅ جميع الصلاحيات الأساسية متوفرة.');
      }

      const config = getConfig(guildId);
      results.push(config.ticketCategoryId ? '✅ كاتيجوري التذاكر معدّة.' : '⚠️ لم يتم تحديد كاتيجوري التذاكر بعد.');

      const embed = baseEmbed().setTitle('🧪 اختبار النظام').setDescription(results.join('\n'));
      return interaction.reply({ embeds: [embed] });
    }
  },
};
