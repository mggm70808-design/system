const { EmbedBuilder } = require('discord.js');
const { db } = require('./database');
const { THEME_COLOR } = require('./utils/helpers');

async function endGiveaway(client, giveaway) {
  db.prepare('UPDATE giveaways SET ended = 1 WHERE id = ?').run(giveaway.id);

  try {
    const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
    if (!channel) return;
    const message = await channel.messages.fetch(giveaway.messageId).catch(() => null);
    if (!message) return;

    const entrants = JSON.parse(giveaway.entrants || '[]');
    let winners = [];
    if (entrants.length) {
      const pool = [...entrants];
      const count = Math.min(giveaway.winnerCount, pool.length);
      for (let i = 0; i < count; i++) {
        const idx = Math.floor(Math.random() * pool.length);
        winners.push(pool.splice(idx, 1)[0]);
      }
    }

    const endedEmbed = new EmbedBuilder()
      .setColor(THEME_COLOR)
      .setTitle('🎉 انتهى القيف اواي!')
      .setDescription(
        `**الجائزة:** ${giveaway.prize}\n**الفائزون:** ${
          winners.length ? winners.map((w) => `<@${w}>`).join(', ') : 'لا يوجد مشاركين 😢'
        }`,
      )
      .setTimestamp();

    await message.edit({ embeds: [endedEmbed], components: [] });

    if (winners.length) {
      await channel.send({
        content: `🎉 مبروك ${winners.map((w) => `<@${w}>`).join(', ')}! لقد فزتم بـ **${giveaway.prize}**`,
      });
    } else {
      await channel.send({ content: `😢 لم يشارك أحد في قيف اواي **${giveaway.prize}**.` });
    }
  } catch (err) {
    console.error('خطأ في إنهاء القيف اواي:', err);
  }
}

async function checkGiveaways(client) {
  const pending = db.prepare('SELECT * FROM giveaways WHERE ended = 0 AND endsAt <= ?').all(Date.now());
  for (const g of pending) {
    await endGiveaway(client, g);
  }
}

function scheduleGiveawayCheck(client, delayMs) {
  setTimeout(() => checkGiveaways(client), Math.min(delayMs, 2147483647));
}

function startGiveawayLoop(client) {
  checkGiveaways(client);
  setInterval(() => checkGiveaways(client), 30_000);
}

module.exports = { startGiveawayLoop, scheduleGiveawayCheck, checkGiveaways };
