const { EmbedBuilder } = require('discord.js');

const THEME_COLOR = 0x9b59ff;
const ERROR_COLOR = 0xed4245;
const SUCCESS_COLOR = 0x57f287;

function baseEmbed() {
  return new EmbedBuilder().setColor(THEME_COLOR).setTimestamp();
}

function errorEmbed(description) {
  return new EmbedBuilder().setColor(ERROR_COLOR).setDescription(`❌ ${description}`);
}

function successEmbed(description) {
  return new EmbedBuilder().setColor(SUCCESS_COLOR).setDescription(`✅ ${description}`);
}

function parseDuration(input) {
  // يدعم صيغ مثل: 10s, 5m, 2h, 1d
  const match = /^(\d+)\s*(s|m|h|d)$/i.exec(input.trim());
  if (!match) return null;
  const amount = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  const multipliers = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return amount * multipliers[unit];
}

function formatMs(ms) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const parts = [];
  if (d) parts.push(`${d}ي`);
  if (h) parts.push(`${h}س`);
  if (m) parts.push(`${m}د`);
  if (!parts.length) parts.push(`${s}ث`);
  return parts.join(' ');
}

module.exports = { baseEmbed, errorEmbed, successEmbed, parseDuration, formatMs, THEME_COLOR };
