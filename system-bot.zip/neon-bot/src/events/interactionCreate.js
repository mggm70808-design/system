const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require('discord.js');
const { db, getConfig } = require('../database');
const { createTicket, claimTicket, closeTicket } = require('../ticketManager');
const { THEME_COLOR, errorEmbed } = require('../utils/helpers');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    try {
      // ============ أوامر السلاش ============
      if (interaction.isChatInputCommand()) {
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) return;
        return await command.execute(interaction);
      }

      // ============ قائمة اختيار نوع التذكرة ============
      if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_select') {
        return await createTicket(interaction, interaction.values[0]);
      }

      // ============ زر فتح تذكرة (بدون أنواع) ============
      if (interaction.isButton() && interaction.customId === 'ticket_open_default') {
        return await createTicket(interaction, null);
      }

      // ============ زر استلام تذكرة ============
      if (interaction.isButton() && interaction.customId.startsWith('ticket_claim_')) {
        const ticketId = interaction.customId.replace('ticket_claim_', '');
        return await claimTicket(interaction, ticketId);
      }

      // ============ زر إغلاق تذكرة ============
      if (interaction.isButton() && interaction.customId.startsWith('ticket_close_')) {
        const ticketId = interaction.customId.replace('ticket_close_', '');
        return await closeTicket(interaction, ticketId);
      }

      // ============ زر دخول القيف اواي ============
      if (interaction.isButton() && interaction.customId.startsWith('giveaway_enter_')) {
        const giveawayId = interaction.customId.replace('giveaway_enter_', '');
        const giveaway = db.prepare('SELECT * FROM giveaways WHERE id = ?').get(giveawayId);
        if (!giveaway || giveaway.ended) {
          return interaction.reply({ content: '❌ هذا القيف اواي انتهى بالفعل.', ephemeral: true });
        }
        const entrants = JSON.parse(giveaway.entrants || '[]');
        if (entrants.includes(interaction.user.id)) {
          const filtered = entrants.filter((id) => id !== interaction.user.id);
          db.prepare('UPDATE giveaways SET entrants = ? WHERE id = ?').run(JSON.stringify(filtered), giveawayId);
          return interaction.reply({ content: '↩️ تم إلغاء مشاركتك في القيف اواي.', ephemeral: true });
        }
        entrants.push(interaction.user.id);
        db.prepare('UPDATE giveaways SET entrants = ? WHERE id = ?').run(JSON.stringify(entrants), giveawayId);
        return interaction.reply({ content: '🎉 تم تسجيل مشاركتك بنجاح! بالتوفيق 🍀', ephemeral: true });
      }

      // ============ زر بدء التقديم -> فتح مودال ============
      if (interaction.isButton() && interaction.customId === 'apply_start') {
        const config = getConfig(interaction.guild.id);
        const existing = db
          .prepare("SELECT * FROM applications WHERE guildId = ? AND userId = ? AND status = 'pending'")
          .get(interaction.guild.id, interaction.user.id);
        if (existing) {
          return interaction.reply({ content: '❌ لديك طلب قيد المراجعة بالفعل.', ephemeral: true });
        }
        if (!config.applyActive) {
          return interaction.reply({ content: '❌ نظام التقديم غير مفعّل حاليًا.', ephemeral: true });
        }

        const modal = new ModalBuilder().setCustomId('apply_modal').setTitle('طلب الانضمام للإدارة');
        const ageInput = new TextInputBuilder().setCustomId('apply_age').setLabel('كم عمرك؟').setStyle(TextInputStyle.Short).setRequired(true);
        const experienceInput = new TextInputBuilder()
          .setCustomId('apply_experience')
          .setLabel('هل لديك خبرة سابقة في الإدارة؟')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true);
        const reasonInput = new TextInputBuilder()
          .setCustomId('apply_reason')
          .setLabel('لماذا تستحق هذا المنصب؟')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true);

        modal.addComponents(
          new ActionRowBuilder().addComponents(ageInput),
          new ActionRowBuilder().addComponents(experienceInput),
          new ActionRowBuilder().addComponents(reasonInput),
        );
        return await interaction.showModal(modal);
      }

      // ============ إرسال المودال ============
      if (interaction.isModalSubmit() && interaction.customId === 'apply_modal') {
        const age = interaction.fields.getTextInputValue('apply_age');
        const experience = interaction.fields.getTextInputValue('apply_experience');
        const reason = interaction.fields.getTextInputValue('apply_reason');
        const answers = JSON.stringify({ age, experience, reason });

        const info = db
          .prepare('INSERT INTO applications (guildId, userId, answers, createdAt) VALUES (?, ?, ?, ?)')
          .run(interaction.guild.id, interaction.user.id, answers, Date.now());

        const config = getConfig(interaction.guild.id);
        if (config.applyLogChannelId) {
          const logChannel = await interaction.guild.channels.fetch(config.applyLogChannelId).catch(() => null);
          if (logChannel) {
            const embed = new EmbedBuilder()
              .setColor(THEME_COLOR)
              .setTitle('📝 طلب تقديم جديد')
              .addFields(
                { name: 'المتقدم', value: `${interaction.user} (${interaction.user.tag})` },
                { name: 'العمر', value: age, inline: true },
                { name: 'الخبرة السابقة', value: experience.slice(0, 1024) },
                { name: 'سبب الاستحقاق', value: reason.slice(0, 1024) },
              )
              .setTimestamp();
            const acceptBtn = new ButtonBuilder().setCustomId(`apply_accept_${info.lastInsertRowid}`).setLabel('✅ قبول').setStyle(ButtonStyle.Success);
            const rejectBtn = new ButtonBuilder().setCustomId(`apply_reject_${info.lastInsertRowid}`).setLabel('❌ رفض').setStyle(ButtonStyle.Danger);
            logChannel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(acceptBtn, rejectBtn)] }).catch(() => {});
          }
        }

        return interaction.reply({ content: '✅ تم إرسال طلبك بنجاح! سيتم مراجعته قريبًا.', ephemeral: true });
      }

      // ============ قبول/رفض التقديم ============
      if (interaction.isButton() && (interaction.customId.startsWith('apply_accept_') || interaction.customId.startsWith('apply_reject_'))) {
        const isAccept = interaction.customId.startsWith('apply_accept_');
        const appId = interaction.customId.replace(isAccept ? 'apply_accept_' : 'apply_reject_', '');
        const application = db.prepare('SELECT * FROM applications WHERE id = ?').get(appId);
        if (!application) return interaction.reply({ content: '❌ لم يتم العثور على هذا الطلب.', ephemeral: true });

        db.prepare('UPDATE applications SET status = ? WHERE id = ?').run(isAccept ? 'accepted' : 'rejected', appId);

        const user = await interaction.client.users.fetch(application.userId).catch(() => null);
        if (user) {
          user
            .send(
              isAccept
                ? `✅ تم قبول طلبك للانضمام لفريق الإدارة في **${interaction.guild.name}**! تهانينا 🎉`
                : `❌ نأسف، تم رفض طلبك للانضمام لفريق الإدارة في **${interaction.guild.name}**.`,
            )
            .catch(() => {});
        }

        const originalEmbed = interaction.message.embeds[0];
        const updatedEmbed = EmbedBuilder.from(originalEmbed).setFooter({
          text: isAccept ? `تم القبول بواسطة ${interaction.user.tag}` : `تم الرفض بواسطة ${interaction.user.tag}`,
        });
        return interaction.update({ embeds: [updatedEmbed], components: [] });
      }

      // ============ زر الموافقة على القوانين ============
      if (interaction.isButton() && interaction.customId.startsWith('rules_accept_')) {
        const roleId = interaction.customId.replace('rules_accept_', '');
        const role = interaction.guild.roles.cache.get(roleId);
        if (!role) return interaction.reply({ content: '❌ الرتبة غير موجودة.', ephemeral: true });

        if (interaction.member.roles.cache.has(roleId)) {
          return interaction.reply({ content: '✅ لديك هذه الرتبة بالفعل.', ephemeral: true });
        }

        await interaction.member.roles.add(role).catch(() => {});
        return interaction.reply({ content: '✅ تمت الموافقة على القوانين وحصلت على الرتبة!', ephemeral: true });
      }
    } catch (err) {
      console.error('خطأ في التفاعل:', err);
      const embed = errorEmbed('حدث خطأ غير متوقع أثناء تنفيذ هذا الإجراء.');
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply({ embeds: [embed], components: [] }).catch(() => {});
      } else {
        await interaction.reply({ embeds: [embed], ephemeral: true }).catch(() => {});
      }
    }
  },
};
