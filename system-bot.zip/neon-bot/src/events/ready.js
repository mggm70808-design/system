const { ActivityType } = require('discord.js');
const { startGiveawayLoop } = require('../giveawayManager');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`✅ تم تسجيل الدخول باسم ${client.user.tag}`);
    client.user.setPresence({
      activities: [{ name: 'Neon System | /ping', type: ActivityType.Watching }],
      status: 'online',
    });
    startGiveawayLoop(client);
  },
};
